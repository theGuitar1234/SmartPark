import sqlite3
import threading
import time
from typing import Any

import flet as ft
import requests
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

DB_NAME = "newsagg.db"
API_HOST = "127.0.0.1"
API_PORT = 8000
API_BASE_URL = f"http://{API_HOST}:{API_PORT}"
ARTICLES_URL = f"{API_BASE_URL}/articles"

BLUE = "#1A2744"
WHITE = "#FFFFFF"
PAGE_BG = "#F5F7FB"
CARD_BG = "#FFFFFF"
BORDER = "#D6E4F0"
TEXT_DARK = "#000000"
TEXT_MUTED = "#373647"
DANGER = "#B92626"
SUCCESS = "#2E7D32"


app = FastAPI(title="News Aggregator API")


class ArticleIn(BaseModel):
    articleID: int
    title: str = Field(..., min_length=5, max_length=20)
    category: str = ""
    publishedDate: str = ""
    published: bool = True


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def create_tables() -> None:
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            CategoryID INTEGER PRIMARY KEY,
            CategoryName TEXT NOT NULL UNIQUE,
            Description TEXT
        );
        """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS authors (
            AuthorID INTEGER PRIMARY KEY,
            FullName TEXT NOT NULL,
            Email TEXT NOT NULL UNIQUE,
            Expertise TEXT
        );
        """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            ArticleID INTEGER PRIMARY KEY,
            Title TEXT NOT NULL CHECK (length(Title) BETWEEN 5 AND 20),
            CategoryID INTEGER,
            AuthorID INTEGER,
            Category TEXT,
            PublishedDate TEXT,
            Published INTEGER DEFAULT 1,
            FOREIGN KEY (CategoryID) REFERENCES categories(CategoryID),
            FOREIGN KEY (AuthorID) REFERENCES authors(AuthorID)
        );
        """)

    conn.commit()
    conn.close()


def seed_data() -> None:
    conn = get_db()
    cursor = conn.cursor()

    cursor.executemany(
        """
        INSERT OR IGNORE INTO categories (CategoryID, CategoryName, Description)
        VALUES (?, ?, ?);
        """,
        [
            (201, "Technology", "Tech and innovation news"),
            (202, "Economy", "Finance and business news"),
            (203, "Sports", "Sports news"),
        ],
    )

    cursor.executemany(
        """
        INSERT OR IGNORE INTO authors (AuthorID, FullName, Email, Expertise)
        VALUES (?, ?, ?, ?);
        """,
        [
            (101, "Kamran I.", "kamran@news.az", "Technology"),
            (102, "Sevinj M.", "sevinj@news.az", "Economy"),
        ],
    )

    cursor.executemany(
        """
        INSERT OR IGNORE INTO articles
            (ArticleID, Title, CategoryID, AuthorID, Category, PublishedDate, Published)
        VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
        [
            (1, "AI in 2025", 201, 101, "Technology", "2025-06-01", 1),
            (2, "Market News", 202, 102, "Economy", "2025-06-05", 1),
            (3, "Sports Today", 203, None, "Sports", "2025-06-10", 1),
        ],
    )

    conn.commit()
    conn.close()


def init_database() -> None:
    create_tables()
    seed_data()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/articles")
def get_articles() -> list[dict[str, Any]]:
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT ArticleID, Title, Category, PublishedDate, Published
        FROM articles
        ORDER BY ArticleID;
        """)

    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "articleID": row["ArticleID"],
            "title": row["Title"],
            "category": row["Category"] or "",
            "publishedDate": row["PublishedDate"] or "",
            "published": bool(row["Published"]),
        }
        for row in rows
    ]


@app.post("/articles")
def add_article(article: ArticleIn) -> dict[str, Any]:
    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute(
            """
            INSERT INTO articles (ArticleID, Title, Category, PublishedDate, Published)
            VALUES (?, ?, ?, ?, ?);
            """,
            (
                article.articleID,
                article.title,
                article.category,
                article.publishedDate,
                int(article.published),
            ),
        )
        conn.commit()

    except sqlite3.IntegrityError as ex:
        conn.close()
        raise HTTPException(
            status_code=400,
            detail=f"ArticleID already exists or invalid article data. {ex}",
        )

    conn.close()

    return {
        "message": "Article added successfully",
        "article": {
            "articleID": article.articleID,
            "title": article.title,
            "category": article.category,
            "publishedDate": article.publishedDate,
            "published": article.published,
        },
    }


@app.delete("/articles/{article_id}")
def delete_article(article_id: int) -> dict[str, str]:
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM articles WHERE ArticleID = ?;", (article_id,))
    conn.commit()

    if cursor.rowcount == 0:
        conn.close()
        raise HTTPException(status_code=404, detail="Article not found")

    conn.close()
    return {"message": f"Article with ID {article_id} deleted successfully"}


def run_backend() -> None:
    uvicorn.run(app, host=API_HOST, port=API_PORT, log_level="warning")


def wait_for_backend(timeout_seconds: float = 6.0) -> None:
    start = time.time()
    while time.time() - start < timeout_seconds:
        try:
            response = requests.get(f"{API_BASE_URL}/health", timeout=0.5)
            if response.status_code == 200:
                return
        except requests.RequestException:
            time.sleep(0.2)


def safe_open(page: ft.Page, control: ft.Control) -> None:
    try:
        page.open(control)
    except Exception:
        try:
            page.overlay.append(control)
            if hasattr(control, "open"):
                control.open = True
            page.update()
        except Exception:
            if isinstance(control, ft.SnackBar):
                page.snack_bar = control
                control.open = True
                page.update()


def show_snack(page: ft.Page, message: str, color: str = BLUE) -> None:
    safe_open(
        page,
        ft.SnackBar(
            content=ft.Text(message, color=WHITE),
            bgcolor=color,
        ),
    )


def setup_page(page: ft.Page, title: str) -> None:
    page.title = title
    page.bgcolor = PAGE_BG
    page.padding = 0
    page.spacing = 0

    try:
        page.window.width = 950
        page.window.height = 720
        page.window.center()
    except Exception:
        page.window_width = 950
        page.window_height = 720
        page.window_center()


def fetch_articles() -> list[dict[str, Any]]:
    response = requests.get(ARTICLES_URL, timeout=8)
    response.raise_for_status()
    data = response.json()

    if isinstance(data, dict):
        data = data.get("articles", [])

    if not isinstance(data, list):
        return []

    return data


def read_article_field(article: dict[str, Any], *keys: str, default: str = "") -> str:
    for key in keys:
        value = article.get(key)
        if value is not None:
            return str(value)
    return default


def is_published(article: dict[str, Any]) -> bool:
    value = article.get("published", False)

    if isinstance(value, bool):
        return value

    if isinstance(value, int):
        return value == 1

    if isinstance(value, str):
        return value.strip().lower() in ["true", "1", "yes", "published", "active"]

    return False


def main(page: ft.Page) -> None:
    setup_page(page, "NewsAgg")

    selected_article_id = {"value": None}

    def show_window1() -> None:
        page.clean()
        selected_article_id["value"] = None

        article_table = ft.DataTable(
            columns=[
                ft.DataColumn(
                    label=ft.Text("ID", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text("Title", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text("Category", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text("Date", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text("Status", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
            ],
            rows=[],
            border=ft.border.all(1, BORDER),
            heading_row_color=BLUE,
            heading_row_height=48,
            data_row_min_height=46,
            data_row_max_height=58,
            column_spacing=35,
        )

        total_text = ft.Text(
            "Total articles: 0",
            size=28,
            weight=ft.FontWeight.BOLD,
            color=BLUE,
        )

        status_text = ft.Text("", size=13, color=TEXT_MUTED)

        def build_main_rows(articles: list[dict[str, Any]]) -> list[ft.DataRow]:
            rows = []

            for article in articles:
                published = is_published(article)

                rows.append(
                    ft.DataRow(
                        cells=[
                            ft.DataCell(
                                ft.Text(read_article_field(article, "articleID", "id"))
                            ),
                            ft.DataCell(
                                ft.Text(read_article_field(article, "title", "Title"))
                            ),
                            ft.DataCell(
                                ft.Text(
                                    read_article_field(article, "category", "Category")
                                )
                            ),
                            ft.DataCell(
                                ft.Text(
                                    read_article_field(article, "publishedDate", "date")
                                )
                            ),
                            ft.DataCell(
                                ft.Text(
                                    "Published" if published else "Draft",
                                    color=SUCCESS if published else DANGER,
                                    weight=ft.FontWeight.BOLD,
                                )
                            ),
                        ]
                    )
                )

            return rows

        def load_articles(e=None) -> None:
            status_text.value = "Loading articles from GET /articles..."
            page.update()

            try:
                articles = fetch_articles()
                article_table.rows = build_main_rows(articles)
                total_text.value = (
                    f"Total articles: {sum(1 for a in articles if is_published(a))}"
                )
                status_text.value = "Data loaded successfully."
                page.update()

            except requests.exceptions.ConnectionError:
                article_table.rows = []
                total_text.value = "Total articles: 0"
                status_text.value = "Backend connection failed."
                page.update()
                show_snack(page, "Could not connect to FastAPI backend.", DANGER)

            except Exception as ex:
                article_table.rows = []
                total_text.value = "Total articles: 0"
                status_text.value = f"Error: {ex}"
                page.update()
                show_snack(page, "Failed to load articles.", DANGER)

        def open_bottom_sheet(e=None) -> None:
            bottom_sheet = ft.BottomSheet(
                content=ft.Container(
                    padding=25,
                    bgcolor=WHITE,
                    border_radius=ft.border_radius.only(top_left=22, top_right=22),
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=12,
                        controls=[
                            ft.Container(
                                width=55,
                                height=5,
                                bgcolor="#CBD5E1",
                                border_radius=20,
                            ),
                            ft.Text(
                                "AI in 2025",
                                size=24,
                                weight=ft.FontWeight.BOLD,
                                color=BLUE,
                            ),
                            ft.Text(
                                "Technology - Jun 1 2025",
                                size=15,
                                color=TEXT_MUTED,
                            ),
                            ft.Divider(),
                            ft.Text(
                                "Full details about the article can be displayed here after expanding the bottom sheet.",
                                size=16,
                                color=TEXT_DARK,
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                    ),
                ),
            )

            safe_open(page, bottom_sheet)

        header = ft.Container(
            height=78,
            bgcolor=BLUE,
            padding=ft.padding.symmetric(horizontal=32),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Text(
                        "NewsAgg",
                        size=32,
                        weight=ft.FontWeight.BOLD,
                        color=WHITE,
                    ),
                    ft.Text(
                        "Window 1 - Main (GET data from FastAPI)",
                        size=16,
                        color=WHITE,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
            ),
        )

        main_content = ft.Container(
            expand=True,
            padding=30,
            content=ft.Column(
                scroll=ft.ScrollMode.AUTO,
                spacing=18,
                controls=[
                    ft.Text(
                        "GET /articles - loads data from FastAPI",
                        size=20,
                        weight=ft.FontWeight.BOLD,
                        color=BLUE,
                    ),
                    ft.ElevatedButton(
                        "Load Articles",
                        icon=ft.Icons.DOWNLOAD,
                        bgcolor=BLUE,
                        color=WHITE,
                        on_click=load_articles,
                    ),
                    status_text,
                    ft.Container(
                        bgcolor=WHITE,
                        border=ft.border.all(1, BORDER),
                        border_radius=12,
                        padding=15,
                        content=article_table,
                    ),
                    ft.Text(
                        "Text widget - Total articles",
                        size=15,
                        color=TEXT_MUTED,
                    ),
                    total_text,
                    ft.Container(
                        bgcolor=WHITE,
                        border=ft.border.all(1, BORDER),
                        border_radius=14,
                        padding=18,
                        on_click=open_bottom_sheet,
                        content=ft.Row(
                            spacing=14,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.Icon(
                                    ft.Icons.KEYBOARD_ARROW_DOWN,
                                    color=BLUE,
                                    size=32,
                                ),
                                ft.Column(
                                    spacing=4,
                                    controls=[
                                        ft.Text(
                                            "Bottom SHEET",
                                            size=16,
                                            weight=ft.FontWeight.BOLD,
                                            color=BLUE,
                                        ),
                                        ft.Text(
                                            "AI in 2025 - Technology - Jun 1 2025.",
                                            size=15,
                                            color=TEXT_DARK,
                                        ),
                                        ft.Text(
                                            "Tap draw handle to expand full details",
                                            size=13,
                                            color=TEXT_MUTED,
                                        ),
                                    ],
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        )

        footer = ft.Container(
            height=62,
            bgcolor=WHITE,
            border=ft.border.only(top=ft.BorderSide(1, BORDER)),
            padding=ft.padding.symmetric(horizontal=30),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_AROUND,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.TextButton(
                        "Headlines",
                        style=ft.ButtonStyle(color=BLUE),
                        on_click=lambda e: show_window1(),
                    ),
                    ft.TextButton(
                        "Categories",
                        style=ft.ButtonStyle(color=BLUE),
                        on_click=lambda e: show_snack(page, "Categories link clicked."),
                    ),
                    ft.TextButton(
                        "Saved",
                        style=ft.ButtonStyle(color=BLUE),
                        on_click=lambda e: show_snack(page, "Saved link clicked."),
                    ),
                    ft.TextButton(
                        "Add/Delete",
                        style=ft.ButtonStyle(color=BLUE),
                        on_click=lambda e: show_window2(),
                    ),
                ],
            ),
        )

        page.add(
            ft.Column(
                expand=True,
                spacing=0,
                controls=[
                    header,
                    main_content,
                    footer,
                ],
            )
        )

        load_articles()

    def show_window2() -> None:
        page.clean()

        article_id_input = ft.TextField(
            label="ArticleID",
            width=260,
            border_color=BLUE,
        )

        title_input = ft.TextField(
            label="Title",
            width=260,
            border_color=BLUE,
            hint_text="5 to 20 characters",
        )

        category_input = ft.TextField(
            label="Category",
            width=260,
            border_color=BLUE,
        )

        published_date_input = ft.TextField(
            label="PublishedDate",
            width=260,
            border_color=BLUE,
            hint_text="2025-06-01",
        )

        selected_text = ft.Text(
            "Selected record: none",
            size=14,
            color=TEXT_MUTED,
        )

        status_text = ft.Text(
            "",
            size=13,
            color=TEXT_MUTED,
        )

        articles_table = ft.DataTable(
            columns=[
                ft.DataColumn(
                    label=ft.Text("ArticleID", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text("Title", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text("Category", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
                ft.DataColumn(
                    label=ft.Text(
                        "PublishedDate", weight=ft.FontWeight.BOLD, color=WHITE
                    )
                ),
                ft.DataColumn(
                    label=ft.Text("Select", weight=ft.FontWeight.BOLD, color=WHITE)
                ),
            ],
            rows=[],
            border=ft.border.all(1, BORDER),
            heading_row_color=BLUE,
            heading_row_height=48,
            data_row_min_height=46,
            data_row_max_height=58,
            column_spacing=35,
        )

        def select_article(article_id: int) -> None:
            selected_article_id["value"] = article_id
            selected_text.value = f"Selected record: {article_id}"
            load_articles()

        def build_manage_rows(articles: list[dict[str, Any]]) -> list[ft.DataRow]:
            rows = []

            for article in articles:
                article_id = int(
                    read_article_field(article, "articleID", "id", default="0")
                )
                is_selected = selected_article_id["value"] == article_id

                rows.append(
                    ft.DataRow(
                        color="#E8F0FE" if is_selected else None,
                        cells=[
                            ft.DataCell(ft.Text(str(article_id))),
                            ft.DataCell(
                                ft.Text(read_article_field(article, "title", "Title"))
                            ),
                            ft.DataCell(
                                ft.Text(
                                    read_article_field(article, "category", "Category")
                                )
                            ),
                            ft.DataCell(
                                ft.Text(
                                    read_article_field(article, "publishedDate", "date")
                                )
                            ),
                            ft.DataCell(
                                ft.ElevatedButton(
                                    "Select",
                                    bgcolor=BLUE if not is_selected else SUCCESS,
                                    color=WHITE,
                                    on_click=lambda e, aid=article_id: select_article(
                                        aid
                                    ),
                                )
                            ),
                        ],
                    )
                )

            return rows

        def load_articles(e=None) -> None:
            status_text.value = "Loading data from GET /articles..."
            page.update()

            try:
                articles = fetch_articles()
                articles_table.rows = build_manage_rows(articles)
                status_text.value = "Table Articles loaded successfully."
                page.update()

            except requests.exceptions.ConnectionError:
                articles_table.rows = []
                status_text.value = "Backend connection failed."
                page.update()
                show_snack(page, "Could not connect to FastAPI backend.", DANGER)

            except Exception as ex:
                articles_table.rows = []
                status_text.value = f"Error: {ex}"
                page.update()
                show_snack(page, "Failed to load articles.", DANGER)

        def clear_form() -> None:
            article_id_input.value = ""
            title_input.value = ""
            category_input.value = ""
            published_date_input.value = ""
            page.update()

        def add_article(e=None) -> None:
            raw_id = article_id_input.value.strip()
            title = title_input.value.strip()
            category = category_input.value.strip()
            published_date = published_date_input.value.strip()

            if not raw_id or not title or not category or not published_date:
                show_snack(
                    page,
                    "Please fill ArticleID, Title, Category, and PublishedDate.",
                    DANGER,
                )
                return

            try:
                article_id = int(raw_id)
            except ValueError:
                show_snack(page, "ArticleID must be an integer.", DANGER)
                return

            if len(title) < 5 or len(title) > 20:
                show_snack(page, "Title must be between 5 and 20 characters.", DANGER)
                return

            payload = {
                "articleID": article_id,
                "title": title,
                "category": category,
                "publishedDate": published_date,
                "published": True,
            }

            try:
                response = requests.post(ARTICLES_URL, json=payload, timeout=8)
                response.raise_for_status()

                show_snack(page, "New article added successfully.", SUCCESS)
                clear_form()
                load_articles()

            except requests.exceptions.HTTPError as ex:
                detail = ""

                try:
                    detail = response.json().get("detail", "")
                except Exception:
                    detail = str(ex)

                show_snack(page, f"POST failed: {detail}", DANGER)

            except requests.exceptions.ConnectionError:
                show_snack(page, "Could not connect to FastAPI backend.", DANGER)

            except Exception as ex:
                show_snack(page, f"Failed to add article: {ex}", DANGER)

        def delete_selected_article(e=None) -> None:
            article_id = selected_article_id["value"]

            if article_id is None:
                show_snack(
                    page, "Select a record from the table before deleting.", DANGER
                )
                return

            try:
                response = requests.delete(f"{ARTICLES_URL}/{article_id}", timeout=8)
                response.raise_for_status()

                show_snack(page, f"Article {article_id} deleted successfully.", SUCCESS)
                selected_article_id["value"] = None
                selected_text.value = "Selected record: none"
                load_articles()

            except requests.exceptions.ConnectionError:
                show_snack(page, "Could not connect to FastAPI backend.", DANGER)

            except Exception as ex:
                show_snack(page, f"Failed to delete article: {ex}", DANGER)

        header = ft.Container(
            height=78,
            bgcolor=BLUE,
            padding=ft.padding.symmetric(horizontal=24),
            content=ft.Row(
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.ElevatedButton(
                        "Back",
                        icon=ft.Icons.ARROW_BACK,
                        bgcolor=WHITE,
                        color=BLUE,
                        on_click=lambda e: show_window1(),
                    ),

                    ft.Container(
                        expand=True,
                        alignment=ft.alignment.center,
                        content=ft.Text(
                            "Add Article",
                            size=30,
                            weight=ft.FontWeight.BOLD,
                            color=WHITE,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ),

                    ft.Container(width=110),
                ],
            ),
        )

        table_section = ft.Container(
            bgcolor=WHITE,
            border=ft.border.all(1, BORDER),
            border_radius=12,
            padding=15,
            content=articles_table,
        )

        form_section = ft.Container(
            bgcolor=WHITE,
            border=ft.border.all(1, BORDER),
            border_radius=14,
            padding=22,
            content=ft.Column(
                spacing=18,
                controls=[
                    ft.Text(
                        "Add new Record - POST /articles",
                        size=20,
                        weight=ft.FontWeight.BOLD,
                        color=BLUE,
                    ),
                    ft.Row(
                        spacing=20,
                        controls=[
                            article_id_input,
                            title_input,
                        ],
                    ),
                    ft.Row(
                        spacing=20,
                        controls=[
                            category_input,
                            published_date_input,
                        ],
                    ),
                    selected_text,
                    ft.Row(
                        spacing=15,
                        controls=[
                            ft.ElevatedButton(
                                "POST",
                                icon=ft.Icons.ADD,
                                bgcolor=BLUE,
                                color=WHITE,
                                on_click=add_article,
                            ),
                            ft.ElevatedButton(
                                "DELETE",
                                icon=ft.Icons.DELETE,
                                bgcolor=DANGER,
                                color=WHITE,
                                on_click=delete_selected_article,
                            ),
                            ft.OutlinedButton(
                                "Refresh",
                                icon=ft.Icons.REFRESH,
                                on_click=load_articles,
                            ),
                        ],
                    ),
                ],
            ),
        )

        main_content = ft.Container(
            expand=True,
            padding=30,
            content=ft.Column(
                scroll=ft.ScrollMode.AUTO,
                spacing=18,
                controls=[
                    ft.Text(
                        "Table Articles - GET /articles",
                        size=21,
                        weight=ft.FontWeight.BOLD,
                        color=BLUE,
                    ),
                    status_text,
                    table_section,
                    form_section,
                ],
            ),
        )

        page.add(
            ft.Column(
                expand=True,
                spacing=0,
                controls=[
                    header,
                    main_content,
                ],
            )
        )

        load_articles()

    show_window1()


if __name__ == "__main__":
    init_database()

    backend_thread = threading.Thread(target=run_backend, daemon=True)
    backend_thread.start()
    wait_for_backend()

    ft.app(target=main)
